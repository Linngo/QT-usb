#include "widget.h"
#include <QApplication>
#include <QIcon>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.setWindowTitle("Update");
    w.setWindowIcon(QIcon(":/1.ico"));
    w.show();

    return a.exec();
}
